#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

bool isCircular(Node* head) {
    if (head == nullptr)
        return false;

    Node* temp = head->next;

    while (temp != nullptr && temp != head) {
        temp = temp->next;
    }

    return (temp == head);
}

int main() {
    
    Node* a = new Node{10, nullptr};
    Node* b = new Node{20, nullptr};
    Node* c = new Node{30, nullptr};

    a->next = b;
    b->next = c;
    c->next = a;  

    cout << (isCircular(a) ? "Circular" : "Not Circular") << endl;

    
    Node* x = new Node{1, nullptr};
    Node* y = new Node{2, nullptr};
    Node* z = new Node{3, nullptr};

    x->next = y;
    y->next = z;
    z->next = nullptr; 

    cout << (isCircular(x) ? "Circular" : "Not Circular") << endl;

    return 0;
}
