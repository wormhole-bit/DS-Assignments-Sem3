#include <iostream>
using namespace std;

struct Node {
    char data;
    Node* next;
    Node* prev;
};

bool isPalindrome(Node* head) {
    if (!head || !head->next) return true;

    
    Node* left = head;
    Node* right = head;
    while (right->next) right = right->next;

    
    while (left != right && right->next != left) {
        if (left->data != right->data) return false;
        left = left->next;
        right = right->prev;
    }

    return true;
}

int main() {
    
    Node* n1 = new Node{'R', nullptr, nullptr};
    Node* n2 = new Node{'A', nullptr, nullptr};
    Node* n3 = new Node{'D', nullptr, nullptr};
    Node* n4 = new Node{'A', nullptr, nullptr};
    Node* n5 = new Node{'R', nullptr, nullptr};

    n1->next = n2; n2->prev = n1;
    n2->next = n3; n3->prev = n2;
    n3->next = n4; n4->prev = n3;
    n4->next = n5; n5->prev = n4;

    cout << (isPalindrome(n1) ? "Palindrome" : "Not Palindrome");
}
