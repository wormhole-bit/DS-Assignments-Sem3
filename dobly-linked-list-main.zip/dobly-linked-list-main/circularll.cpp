#include <iostream>
using namespace std;
class Node {
public:
    int data;
    Node* next;
    Node(int val) {
        data = val;
        next = nullptr;
    }
};
class CircularLinkedList {
public:
    Node* head;
    CircularLinkedList() { head = nullptr; }
    void insertAtEnd(int val) {
        Node* newNode = new Node(val);
        if (head == nullptr) {
            head = newNode;
            newNode->next = head;
            return;
        }
        Node* temp = head;
        while (temp->next != head)
            temp = temp->next;
        temp->next = newNode;
        newNode->next = head;
    }
    void display() {
        if (head == nullptr) return;
        Node* temp = head;
        do {
            cout << temp->data << " -> ";
            temp = temp->next;
        } while (temp != head);
        cout << "(head)\n";
    }
     void displaywithhead() {
        if (head == nullptr) return;
        Node* temp = head;
        do {
            cout << temp->data << " -> ";
            temp = temp->next;
        } while (temp != head);
        cout << "(head) = "<<temp->data<<"\n";

    }
    void deleteNode(int val) {
        if (head == nullptr) return;
        Node* curr = head;
        Node* prev = nullptr;
        if (head->next == head && head->data == val) {
            delete head;
            head = nullptr;
            return;
        }
        do {
            if (curr->data == val) break;
            prev = curr;
            curr = curr->next;
        } while (curr != head);
        if (curr == head) { 
            prev = head;
            while (prev->next != head)
                prev = prev->next;
            head = head->next;
            prev->next = head;
            delete curr;
        } else if (curr != nullptr) {
            prev->next = curr->next;
            delete curr;
        }
    }
    void size(){
        Node *temp = head;
        int count = 0;
        while(temp->next!=head){
            count++;
            temp = temp->next;
        }
        cout<<"size : "<<count+1<<endl;
    }
};

int main() {
    CircularLinkedList cll;
    cll.insertAtEnd(10);
    cll.insertAtEnd(20);
    cll.insertAtEnd(30);
    cll.size();
    cll.display();
    cll.deleteNode(20);
    cll.size();
    cll.displaywithhead();
    return 0;
}
