#include<iostream>
using namespace std;
class node{
public:
int data;
node *next;
node(int data){
    this->data = data;
    this->next = NULL;
}
~node(){
    if(this->next!=NULL){
        delete next;
        this->next = NULL;
    }
    cout<<"memory is freed up no tension "<<endl;
}
};
void printall(node *&tail){
    if(tail == NULL) cout<<"empty list "<<endl;
    else{
node *temp = tail;
do{
    cout<<tail->data<<" ";
    tail = tail->next;
}
while(tail!=temp);
cout<<endl;
}
}
void insertnode(node *& tail,int element, int dat){
if(tail==NULL){
    node *temp = new node(dat);
    tail=temp;
    temp->next = temp;
}else{
    node *curr = tail;
    while(curr->data!=element){
        curr = curr->next;
    }
    node *temp = new node(dat);
    temp->next = curr->next;
    curr->next = temp;
}
}
void deletenode(node *&tail,int val){
    if(tail==NULL){
        cout<<"error the list is empty "<<endl;
    }
    else{
        node *prev = tail;
        node *curr = prev->next;
        while(curr->data!=val){
            prev = curr;
            curr = curr->next;
        }
        prev->next = curr->next;
        if(curr == prev ){tail == NULL;}
       else if(curr == tail){tail = prev;}
        curr->next = NULL;
        delete curr;    
    }

}
int main (){
    node *tail = NULL;
    insertnode(tail,3,5);
    printall(tail);
    insertnode(tail,5,69);
    printall(tail);


    return 0;
}