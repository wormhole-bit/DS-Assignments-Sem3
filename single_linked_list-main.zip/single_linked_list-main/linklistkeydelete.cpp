#include<iostream>
using namespace std;
class node{
public:
int data;
node *next;
node(int data){
    this->data = data;
    this->next = NULL;
}
~node(){
    cout<<"memory is freed up no tension "<<endl;
}
};
void tailinsert(node *&tail,int dat){
    node *temp = new node(dat);
    tail->next = temp;
    tail = tail->next;

}
void headinsert(node* &head,int dat){
node *temp = new node(dat);
temp->next = head; 
head = temp;
}
void deletenode(node *&head,node *&tail,int position){
if(position == 1){
node *temp = head;
head = head->next;
if(head==NULL) tail=NULL;
temp->next = NULL;
delete temp; 
}
else{
node *curr = head;
node *prev  = head;
int cnt = 1;
while(cnt < position){
prev = curr;
curr = curr->next;
cnt++;
}
if(curr->next == NULL) tail = prev;
prev->next = curr->next;
curr ->next = NULL;
delete curr;
}}
void positioninsert(node *&head,node *& tail,int position, int dat){
    if(position==1){
        headinsert(head,dat);
        return;
    }
    else{
 node *temp = head;
 int cunt = 1;
 while(cunt<position-1) {
temp = temp->next;
cunt++; 
}
if(temp->next == NULL){
    tailinsert(tail,dat);
    return ;
}
node *inser = new node(dat);
inser->next=temp->next;
temp->next = inser;
}
}
void printall(node *&head){
node *temp = head;
while(temp!=NULL){
    cout<<temp->data<<" ";
    temp = temp->next;
}
cout<<endl;
}
void keydelete(node *&head,node *&tail,int key){
node *temp = head;
node *prev = head;
int count  = 0;
while(temp != NULL){
if(temp->data == key){
    count++;
    if(temp == head){
        head = temp->next;
    }
    if(temp->next == NULL){
        tail = prev;
    }
    node *todel = temp;
    prev->next = temp ->next;
    temp = temp->next;
    delete todel;

}
else{
    prev = temp;
temp = temp->next;
}
}
cout<<"totassl occurance of key is : "<<count<<endl;
}


int main (){
node *node1 = new node(1);
node *head = node1;//head pointed to node1
node *tail = node1;
headinsert(head,1);
headinsert(head,1);
headinsert(head,2);
headinsert(head,2);
headinsert(head,3);
headinsert(head,1);
headinsert(head,3);
headinsert(head,3);
headinsert(head,4);
headinsert(head,1);
printall(head);
cout<<endl;
keydelete(head,tail,1);
cout<<endl;
printall(head);
cout<<endl;
cout<<"head data : "<<head->data;
cout<<endl;
cout<<"tail data : "<<tail->data;
    return 0;
}