#include<iostream>
using namespace std;
class node{
public:
int data;
node *next;
node(int data){
    this->data = data;
    this->next = NULL;
}
~node(){
    cout<<"memory is freed up no tension "<<endl;
}
};
void tailinsert(node *&tail,node *&head){
    int dat;
    cout<<"enter data : ";
    cin>>dat;
    node *temp = new node(dat);
    if(head == NULL){
        head = temp;
        tail  = temp;
        return ;
    }
    tail->next = temp;
    tail = tail->next;

}
void headinsert(node* &head,node *&tail){
    int dat;
    cout<<"enter value : ";
    cin>>dat;
node *temp = new node(dat);
temp->next = head; 
head = temp;
if(tail == NULL) tail = head;
}
void deleteheadnode(node *&head,node *&tail){
    node *temp = head;
    head = head->next;
    if(head==NULL) tail=NULL;
temp->next = NULL;
delete temp; 
}
 void deletetailnode(node *&head,node *&tail){
    if(head == NULL) return;
      if(head->next == NULL){
        delete head;
        head = tail = NULL;
        return;
    }
node *curr = head;
while(curr->next!=tail){
curr = curr->next;
}
delete tail;
tail = curr;
tail->next = NULL;
 }
void deletenode(node *&head,node *&tail){
    int position;
    cout<<"enter poston : ";
    cin>>position;
if(position == 1){
deleteheadnode(head,tail);
}
else{
node *curr = head;
node *prev  = head;
int cnt = 1;
while(cnt < position){
prev = curr;
curr = curr->next;
cnt++;
}
if(curr->next == NULL) deletetailnode(head,tail);
else{
    prev->next = curr->next;
curr ->next = NULL;
delete curr;
}
}}
void positioninsert(node *&head,node *& tail){
   int position;
   cout<<"enter position ";
   cin>>position;

    if(position==1){
        headinsert(head,tail);
        return;
    }
    else{
 node *temp = head;
 int cunt = 1;
 while(cunt<position-1) {
temp = temp->next;
cunt++; 
}
if(temp->next == NULL){
    tailinsert(tail,head);
    return ;
}
   int dat;
   cout<<"enter data ";
   cin>>dat;
node *inser = new node(dat);
inser->next=temp->next;
temp->next = inser;
}
}
void printall(node *&head){
node *temp = head;
while(temp!=NULL){
    cout<<temp->data<<" ";
    temp = temp->next;
}
cout<<endl;
}
void search(node *&head){
int dat;
cout<<"enter data to find : ";
cin>>dat;
int count  = 0;
node * temp = head;
while(temp->data != dat && temp->next != NULL){
count++;
temp = temp->next;
}
cout<<"the postion of node from head is : "<<count<<endl;
}

int main (){
    node *node1 = new node(10);
node* head = node1;
node *tail = node1;

while(1){
int n;
cout<<"choose what to de from menu and enter number : "<<endl;
cout<<"1) insert at beg \n2) ensert at end \n3) insert at pos\n4) delete at head\n5) delete end\n6) delete postion\n7) search\n8) printall\n 0 to brak\n";
cin>>n;
switch(n){
case 0 : cout<<"endind loop ";break;
case 1 : headinsert(head,tail);break;
case 2 : tailinsert(tail,head);break;
case 3 : positioninsert(head,tail); break;
case 4 : deleteheadnode(head , tail );break;
case 5 : deletetailnode(head,tail);break;
case 6 : deletenode(head , tail ); break;
case 7 : search(head);
case 8 : printall(head);break;
default : cout<<"error 404 invalid ";
}
if(n==0) break;
}
return 0;
}
