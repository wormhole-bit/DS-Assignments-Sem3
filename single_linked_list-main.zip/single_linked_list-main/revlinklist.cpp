#include<iostream>
using namespace std;
class node{
public:
int data;
node *next;
node(int data){
    this->data = data;
    this->next = NULL;
}
~node(){
    if(this->next!=NULL){
        delete next;
        this->next = NULL;
    }
    cout<<"memory is freed up no tension "<<endl;
}

};
void inserthead(node *& head,int dat){
    node *temp = new node(dat);
    temp->next = head;
    head = temp;
}
void positioninsert(node *&head,int position,int dat){
    if(position==1){
        inserthead(head,dat);
        return;
    }
    else{
        int count = 1;
        node *temp = head;
        while(count < position-1){
            temp = temp->next;
            count++;
        }
        if(temp->next==NULL){
            node *temp1 = new node(dat);
            temp->next = temp1;
        }
        else{
             node *temp1 = new node(dat);
             temp1->next = temp->next;
             temp->next = temp1;
        }
    }

}
void printall(node *&head){
    node *temp = head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp = temp->next;
    }
    cout<<endl;
}

void revllist(node *&head){
node *temp = head;
if(temp==NULL) {
    cout<<"empty linked list cant revese"<<endl;
    return ;
}
else if(temp->next==NULL) {
    cout<<"only 1 element cant reverse "<<endl;
    return;
}
else{
    node *after  = NULL;
    node *prev = NULL;
    while(temp!=NULL){
        after = temp->next;
        temp->next = prev;
        prev = temp;
        temp = after;
        
    }
    head = prev;
}
}
int main (){
node *node1 = new node(141);
node* head = node1;
positioninsert(head,2,151);
inserthead(head,131);
inserthead(head,111);
positioninsert(head,2,121);
inserthead(head,101);
printall(head);
cout<<"reversed linked list : ";
revllist(head);
printall(head);
    return 0;
}