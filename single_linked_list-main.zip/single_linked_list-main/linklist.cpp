#include<iostream>
using namespace std;
class node{
public:
int data;
node *next;
node(int data){
    this->data = data;
    this->next = NULL;
}
~node(){
    if(this->next!=NULL){
        delete next;
        this->next = NULL;
    }
    cout<<"memory is freed up no tension "<<endl;
}
};
void tailinsert(node *&tail,int dat){
    node *temp = new node(dat);
    tail->next = temp;
    tail = tail->next;

}
void headinsert(node* &head,int dat){
node *temp = new node(dat);
temp->next = head; 
head = temp;
}
void deletenode(node *&head,node *&tail,int position){
if(position == 1){
node *temp = head;
head = head->next;
if(head==NULL) tail=NULL;
temp->next = NULL;
delete temp; 
}
else{
node *curr = head;
node *prev  = head;
int cnt = 1;
while(cnt < position){
prev = curr;
curr = curr->next;
cnt++;
}
if(curr->next == NULL) tail = prev;
prev->next = curr->next;
curr ->next = NULL;
delete curr;
}}
void positioninsert(node *&head,node *& tail,int position, int dat){
    if(position==1){
        headinsert(head,dat);
        return;
    }
    else{
 node *temp = head;
 int cunt = 1;
 while(cunt<position-1) {
temp = temp->next;
cunt++; 
}
if(temp->next == NULL){
    tailinsert(tail,dat);
    return ;
}
node *inser = new node(dat);
inser->next=temp->next;
temp->next = inser;
}
}
void printall(node *&head){
node *temp = head;
while(temp!=NULL){
    cout<<temp->data<<" ";
    temp = temp->next;
}
cout<<endl;
}
void findmiddle(node *&head){
    node * temp = head;
    int count = 0;
    while(temp != NULL){
        temp = temp->next;
        count++;
    }
    int cunt;
    node *temp1 = head;
    if(count%2 != 0) cunt = count/2;
    else cunt = count/2;
   // cout<<"count : "<<count;
    while(cunt){
        cunt--;
        temp1 = temp1->next;
    }
    cout<<"data of middle is : "<<temp1->data;
}
int main (){
node *node1 = new node(101);
node *head = node1;//head pointed to node1
node *tail = node1;
printall(head);
headinsert(head,111);
printall(head);
tailinsert(tail,151);
printall(head);
positioninsert(head,tail,4,121);
printall(head);
deletenode(head,tail,4);
printall(head);
findmiddle(head);
tailinsert(tail,151);
findmiddle(head);
    return 0;
}