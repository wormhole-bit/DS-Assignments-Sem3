#include <iostream>
#include <queue>
using namespace std;

queue<int> interleave(queue<int> q) {
    int n = q.size();
    if (n % 2 != 0) {
        cout << "Queue must have even number of elements\n";
        return q;
    }

    queue<int> firstHalf;
    for (int i = 0; i < n/2; i++) {
        firstHalf.push(q.front());
        q.pop();
    }

    queue<int> result;

    while (!firstHalf.empty()) {
        result.push(firstHalf.front());
        firstHalf.pop();

        result.push(q.front());
        q.pop();
    }

    return result;
}

int main() {
    queue<int> q, res;
    int x, n;

    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> x;
        q.push(x);
    }

    res = interleave(q);

    while (!res.empty()) {
        cout << res.front() << " ";
        res.pop();
    }
}
