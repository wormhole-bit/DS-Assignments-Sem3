#include <iostream>
#include <cstring>  // for strlen
#include <cstdlib>  // for atoi
using namespace std;

#define MAX 100

// Stack implementation
class Stack {
    int arr[MAX];
    int top;
public:
    Stack() { top = -1; }

    void push(int x) {
        if (top == MAX - 1) {
            cout << "Stack Overflow\n";
            return;
        }
        arr[++top] = x;
    }

    int pop() {
        if (top == -1) {
            cout << "Stack Underflow\n";
            return -1;
        }
        return arr[top--];
    }

    bool isEmpty() {
        return (top == -1);
    }
};

// Function to evaluate postfix expression
int evaluatePostfix(char exp[]) {
    Stack st;
    for (int i = 0; exp[i] != '\0'; i++) {
        char ch = exp[i];

        // If operand (digit)
        if (ch >= '0' && ch <= '9') {
            st.push(ch - '0');   // convert char to int
        }
        else {
            // Operator → pop two operands
            int val2 = st.pop();
            int val1 = st.pop();

            switch (ch) {
                case '+': st.push(val1 + val2); break;
                case '-': st.push(val1 - val2); break;
                case '*': st.push(val1 * val2); break;
                case '/': st.push(val1 / val2); break;
                default: cout << "Invalid operator: " << ch << endl;
            }
        }
    }
    return st.pop();  // Final result
}

int main() {
    char exp[MAX];
    cout << "Enter a postfix expression: ";
    cin >> exp;    int result = evaluatePostfix(exp);
    cout << "Result = " << result << endl;
    return 0;
}
