#include<bits/stdc++.h>
using namespace std;
static const int maxx=4;
class stackk{
int arr[maxx];
int top;
public:
stackk(){top=-1;}
void push(){
    if(top == maxx-1){
        cout << "stack is full : ";
    }
    else{
        cout<<"enter value to be pushed : ";
        int a;
        cin>>a;
        top++;
        arr[top] = a;
    }
}
void pop(){
    if(top == -1) cout<<"stack is empty ";
    else top--;
}
void isempty(){
if(top == -1) cout<<"is empty true";
else cout<<"false";
}
void isfull(){
    if(top==maxx-1) cout<<"true is fill";
    else cout<<"false";
}
void peek(){
    if(top == -1) cout<<"stack is empty ";
    else cout<<"the top element is : "<<arr[top]<<endl;
}
void disp(){
    if(top == -1) cout<<"stack is empty ";
    else{
        for (int i = top; i > 0; i--)
        {
           cout<<arr[i]<<"  ";
        }
    }
}

};

int main (){
      stackk s1;
while (1)
{
    cout<<endl<<"choose a function to perform in stcak from menu : "<<endl;
    cout<<" (i) push()\n (ii) pop()\n (iii) isEmpty()\n (iv) isFull()\n (v) display()\n (vi) peek() \n (vii) break"<<endl;
    int n;
    cin>>n;
    switch (n) {
    case (1) : s1.push(); break;
    case (2) : s1.pop(); break;
    case (3) : s1.isempty(); break;
    case (4) : s1.isfull(); break;
    case (5) : s1.disp(); break;
    case (6) : s1.peek(); break;
    case (7) : n=0; break;
    }
    if(n==0) break;
}
    return 0;
}