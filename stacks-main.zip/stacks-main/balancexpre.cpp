#include <iostream>
using namespace std;
int isBalanced(const char expr[]) {
    char stack[100];  
    int top = -1;     
    for (int i = 0; expr[i] != '\0'; i++) {
        char ch = expr[i];
        if (ch == '(' || ch == '{' || ch == '[') {
            stack[++top] = ch;
        }
        else if (ch == ')' || ch == '}' || ch == ']') {
            if (top == -1) return 0;
            char topChar = stack[top--]; 
            if ((ch == ')' && topChar != '(') ||
                (ch == '}' && topChar != '{') ||
                (ch == ']' && topChar != '['))  return 0; 
      }
    }
    return (top == -1); 
}
int main() {
    char expr[100];
    cout << "Enter an expression: ";
    cin >> expr;
    int a = isBalanced(expr);
    if (a==1)
        cout << "Balanced\n";
    else
        cout << "Not Balanced\n";

    return 0;
}
